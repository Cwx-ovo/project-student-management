﻿#define _CRT_SECURE_NO_WARNINGS
#pragma once
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<windows.h>
#include<conio.h>//无回显
typedef struct administrator {
	char account[20];
	char password[20];
}adm;
typedef struct teacher {
	char name[20];
	char psd[20];
	int id;
	char gender[20];
	char birth[20];
	struct teacher* next;
}tea;
typedef struct student {
	char name[20];
	char psd[20];
	int id;
	char gender[20];
	char birth[30];
	float math;
	float chinese;
	float english;
	struct student* next;
}stu;

// ========= 新增：保存当前登录用户指针 =========
extern tea* g_cur_teacher;
extern stu* g_cur_student;

//功能板块
void inputPassword(char* pwd, int maxLen);//无回显输入函数
void welcome();//欢迎函数
void menu(int m);//菜单
int checkgender(char* p);//检查性别
int checkbirth(const char* s);//检查日期
//管理员板块
int loginadmin();//admin登陆验证函数
void changeAdminpwd();//修改管理员登陆密码
tea* teachercreat();//创建一个教师链表的头节点
tea* addteacher();//添加一个教师
int deleteteacher(int id);//删除指定id的教师
int changeteacher();//修改教师信息
int actionadmin();//具体操作函数
int verifyteaid(int id);//验证教师工号有无重复
//教师板块
stu* studentcreat();//创建一个学生链表头节点
int loginteacher();//教师登陆函数
void changeTeacherpwd();//修改教师登陆密码
int actionteacher();//教师具体操作函数
void showteacherself();//显示教师自身信息
stu* addstudent();//添加一位新学生
int deletestudent(int id);//删除一名指定学好号的学生
int changestudent();//修改指定学号学生的信息
void lookastudent();//查询指定学号学生信息
void idbubble();//将学生按学号从小到大排序
void showstudent();//遍历打印学生信息
void scorebubble();//将学生按三门课的总成绩从高到低排序
int verifystuid(int id);
//学生板块
int loginstudent();//学生登录函数
void changeStudentpwd();//修改学生登陆密码
void showstudentself();//显示学生自身信息
int actionstudent();//学生具体操作函
//文件持久化板块
void adminSave();//把管理员信息写入 admin.txt
void adminLoad();//启动时从 admin.txt 读入管理员信息
void teacherSave();//把教师链表写入 teachers.txt
void teacherLoad();//启动时从 teachers.txt 读入教师链表
void studentSave();//把学生链表写入 students.txt
void studentLoad();//启动时从 students.txt 读入学生链表
