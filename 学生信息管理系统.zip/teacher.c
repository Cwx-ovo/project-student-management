﻿#include"project.h"
// 定义全局登录指针
tea* g_cur_teacher = NULL;
stu* g_cur_student = NULL;

tea teacher;
tea* p;
stu* pt;

//========== 文件持久化：学生链表 ==========
void studentSave() {//把学生链表整体写入 students.txt
	FILE* fp = fopen("students.txt", "w");
	if (fp == NULL) { printf("students.txt 打开失败\n"); return; }
	stu* s = pt->next;
	while (s != NULL) {
		fprintf(fp, "%s %s %d %s %s %.2f %.2f %.2f\n",
			s->name, s->psd, s->id, s->gender, s->birth,
			s->math, s->chinese, s->english);
		s = s->next;
	}
	fclose(fp);
}
void studentLoad() {//启动时从 students.txt 读入学生链表
	FILE* fp = fopen("students.txt", "r");
	if (fp == NULL) return;
	stu* tail = pt;
	char name[20], psd[20], gender[20], birth[30];
	int id;
	float math, chinese, english;
	while (fscanf(fp, "%s %s %d %s %s %f %f %f",
		name, psd, &id, gender, birth, &math, &chinese, &english) == 8) {
		stu* q = (stu*)malloc(sizeof(stu));
		if (q == NULL) break;
		strcpy(q->name, name);
		strcpy(q->psd, psd);
		q->id = id;
		strcpy(q->gender, gender);
		strcpy(q->birth, birth);
		q->math = math;
		q->chinese = chinese;
		q->english = english;
		q->next = NULL;
		tail->next = q;
		tail = q;
	}
	fclose(fp);
}
stu* studentcreat() {//创建一个学生链表头节点
	pt = (stu*)malloc(sizeof(stu));
	if (pt == NULL) { printf("pt malloc fail\n");return NULL; }
	pt->next = NULL;
	return pt;
}
int verifystuid(int id) {
	stu* temp = pt;
	if (pt->next == NULL) { return 0; }
	while (temp->next != NULL) {
		temp = temp->next;
		if (temp->id == id) { printf("输入学号与现有学号重复！请重新输入\n");return 1; }
	}
	return 0;
}
stu* addstudent() {//添加一位新学生
	stu* pnew = (stu*)malloc(sizeof(stu));
	if (pnew == NULL) { printf("pnew malloc fail\n");return NULL; }
	printf("请依次输入：姓名、登陆密码、学号、性别、出生年月日、数学成绩、语文成绩、英语成绩:\n例：xxx xxx123 1001 男 2004/07/22 100 99 98\n(注意学号不可以重复！！！)\n");
	scanf("%s%s%d%s%s%f%f%f", pnew->name, pnew->psd, &pnew->id, pnew->gender, pnew->birth, &pnew->math, &pnew->chinese, &pnew->english);
	if (verifystuid(pnew->id) == 1) {
		while (1) {
			scanf("%d", &pnew->id);
			if (verifystuid(pnew->id) == 0) { break; }
		}
	}
	if (checkgender(pnew->gender) == -1) {
		while (1) {
			scanf("%s", pnew->gender);
			if (checkgender(pnew->gender) == 1) { break; }
		}
	}
	if (checkbirth(pnew->birth) == -1) {
		printf("日期输入非法，请单独重新输入日期即可\n");
		while (1) {
			scanf("%s", pnew->birth);
			if (checkbirth(pnew->birth) == -1) { printf("日期输入非法，请单独重新输入日期即可\n"); }
			if (checkbirth(pnew->birth) == 1) { break; }
		}
	}
	pnew->next = pt->next;
	pt->next = pnew;
	return pt;
}

//教师登录：遍历链表匹配账号密码
int loginteacher() {
	char input_name[20];
	char input_pwd[20];
	for (int i = 1; i <= 3; i++)
	{
		printf("请输入教师账户（姓名）：\n");
		scanf("%s", input_name);
		tea* cur = p->next;
		g_cur_teacher = NULL;
		while (cur != NULL)
		{
			if (strcmp(cur->name, input_name) == 0)
			{
				for (int j = 1;j <= 3;j++)
				{
					printf("请输入密码：\n");
					inputPassword(input_pwd, 20);
					if (strcmp(cur->psd, input_pwd) == 0)
					{
						g_cur_teacher = cur;
						printf("教师账户登陆成功！\n");
						return 1;
					}
					else
					{
						printf("密码错误，剩余%d次\n", 3 - j);
					}
				}
				return -1;
			}
			cur = cur->next;
		}
		printf("账户不存在！剩余尝试：%d\n", 3 - i);
	}
	return -1;
}

// 修改当前登录教师密码
void changeTeacherpwd() {
	if (g_cur_teacher == NULL) return;
	char newpwd[20];
	printf("请输入新的密码：\n");
	while (1) {
		scanf("%s", newpwd);
		if (strcmp(newpwd, g_cur_teacher->psd) == 0) {
			printf("与旧密码重复请重新输入：\n");
		}
		else {
			strcpy(g_cur_teacher->psd, newpwd);
			printf("密码修改成功\n");
			teacherSave();
			break;
		}
	}
	return;
}

void showteacherself() {
	if (g_cur_teacher == NULL) return;
	printf("姓名：%s	密码：%s	工号：%d	性别：%s	出生年月：%s\n",
		g_cur_teacher->name, g_cur_teacher->psd, g_cur_teacher->id,
		g_cur_teacher->gender, g_cur_teacher->birth);
	return;
}

int deletestudent(int id) {//删除指定id的学生
	stu* del = pt->next;
	if (del == NULL) { printf("无学生可删除\n"); return 0; }
	stu* h = pt;
	while (del != NULL) {
		if (del->id == id) {
			h->next = del->next;
			free(del);
			del = NULL;
			del = h->next;
		}
		else {
			h = h->next;
			del = del->next;
		}
	}
	return 0;
}
int changestudent() {
	stu* temp = pt->next;
	int x;
	if (temp == NULL) { printf("无学生可供修改\n");return -1; }
	printf("请输入您想修改学生的学号：\n");
	scanf("%d", &x);
	while (temp != NULL && temp->id != x) {
		temp = temp->next;
	}
	if (temp == NULL) {
		printf("找不到该学生\n");
		return -1;
	}
	printf("1.name	  2.gender    3.birth   4.语文成绩   5.数学成绩   6.英语成绩\n");
	printf("请输入您想修改的信息：\n");
	int k;
	scanf("%d", &k);
	char name[20];  char gender[20]; char birth[20];
	switch (k) {

	case 1:
		printf("请输入新的姓名：\n");
		scanf("%s", name);strcpy(temp->name, name);
		printf("修改姓名成功\n");
		break;
	case 2:
		printf("请输入性别：\n");
		scanf("%s", gender);strcpy(temp->gender, gender);
		printf("修改性别成功\n");
		break;
	case 3:
		printf("请输入新的出生日期：\n");
		scanf("%s", birth);strcpy(temp->birth, birth);
		printf("修改出生日期成功\n");
		break;
	case 4:
		printf("请输入新的语文成绩：\n");
		scanf("%f", &temp->chinese);
		printf("修改语文成绩成功\n");
		break;
	case 5:
		printf("请输入新的数学成绩：\n");
		scanf("%f", &temp->math);
		printf("修改数学成绩成功\n");
		break;
	case 6:
		printf("请输入新的英语成绩：\n");
		scanf("%f", &temp->english);
		printf("修改英语成绩成功\n");
		break;
	}
	return 0;
}
void lookastudent() {
	stu* temp = pt->next;
	if (temp == NULL) { printf("暂无学生可供查询\n");return; }
	int x;
	printf("请输入您想查询的学生学号：\n");
	scanf("%d", &x);

	while (temp != NULL && temp->id != x) {
		temp = temp->next;
	}
	if (temp == NULL) {
		printf("未找到学生\n");
		return;
	}
	printf("姓名：%s\n密码：%s\n学号：%d\n性别：%s\n出生日期：%s\n语文：%.2f\n数学：%.2f\n英语：%.2f\n",
		temp->name, temp->psd, temp->id, temp->gender, temp->birth, temp->chinese, temp->math, temp->english);
	return;
}
void idbubble() {
	stu* prev, * curr, * nxt;
	int swap;
	if (pt->next == NULL) { printf("系统中暂无学生\n");return; }
	do {
		swap = 0;
		prev = pt;
		curr = pt->next;
		nxt = curr->next;
		while (nxt != NULL) {
			if (curr->id > nxt->id) {
				prev->next = nxt;
				curr->next = nxt->next;
				nxt->next = curr;

				prev = nxt;
				nxt = curr->next;
				swap = 1;
			}
			else {
				prev = curr;
				curr = nxt;
				nxt = curr->next;

			}
		}
	} while (swap);
	return;
}
void scorebubble() {
	stu* prev, * curr, * nxt;
	int swap;
	if (pt->next == NULL) { printf("系统中暂无学生\n");return; }
	do {
		swap = 0;
		prev = pt;
		curr = pt->next;
		nxt = curr->next;
		while (nxt != NULL) {
			if ((curr->chinese + curr->math + curr->english) < (nxt->chinese + nxt->english + nxt->math)) {
				prev->next = nxt;
				curr->next = nxt->next;
				nxt->next = curr;
				prev = nxt;
				nxt = curr->next;
				swap = 1;
			}
			else {
				prev = curr;
				curr = nxt;
				nxt = curr->next;
			}
		}
	} while (swap);
	return;
}
void showstudent() {
	stu* p = pt;
	while (p->next != NULL) {
		p = p->next;
		printf("学号：%d	姓名：%s	密码：%s  性别：%s  出生日期：%s  语文：%.2f  数学：%.2f  英语：%.2f\n", p->id, p->name, p->psd, p->gender, p->birth,
			p->chinese, p->math, p->english);
	}
	return;
}
int actionteacher() {
	int k;
	printf("请输入您想进行的操作：\n");
	scanf("%d", &k);
	switch (k) {
	case 1: changeTeacherpwd();break;
	case 2:  showteacherself();break;
	case 3:
		addstudent();
		studentSave();
		printf("添加成功\n");
		break;
	case 4:
		printf("请输入您想删除的学生学号：\n");
		int id;
		scanf("%d", &id);
		deletestudent(id);
		studentSave();
		printf("删除成功\n");
		break;
	case 5:
		changestudent();
		studentSave();
		break;
	case 6:
		lookastudent();
		break;
	case 7:
		idbubble();
		showstudent();
		break;
	case 8:
		scorebubble();
		showstudent();
		break;
	case 9:
		return -1;
	}
	return 0;
}