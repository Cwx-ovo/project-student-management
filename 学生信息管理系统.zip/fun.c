﻿#include"project.h"
void welcome() {
	printf("******************************************************************\n");
	printf("|                                                                |\n");
	printf("|                   欢迎进入学生管理系统                         |\n");
	printf("|                                                                |\n");
	printf("|");
	int i;
	for (i = 0; i < 64; i++)  //输出欢迎界面的动效
	{
		printf("_");
		Sleep(20);
	}
	printf("|\n");
	printf("|                                                                |\n");
	printf("|                                                                |\n");
	printf("|                      ______________                            |\n");
	printf("|                      | __________ |                            |\n");
	printf("|                      ||          ||                            |\n");
	printf("|                      || Welcome! ||                            |\n");
	printf("|                      ||__________||                            |\n");
	printf("|                      |____________|                            |\n");
	printf("|                          /____\\                                |\n");
	printf("|                                                                |\n");
	printf("|                                                                |\n");
	printf("|                                                                |\n");
	printf("|                       作者：cwx                                |\n");
	printf("|                                                                |\n");
	printf("|                                                                |\n");
	printf("|                                                                |\n");
	printf("******************************************************************\n");

}

void inputPassword(char* pwd, int maxLen)//无回显输入函数
{
	int i = 0;
	char ch;
	while (1)
	{
		ch = _getch();
		if (ch == '\r')              // 回车结束
		{
			pwd[i] = '\0';
			break;
		}
		else if (ch == '\b')         // 退格删除
		{
			if (i > 0)
			{
				i--;
				printf("\b \b");     // 光标左移，擦除星号
			}
		}
		else if (i < maxLen - 1)     // 防止数组越界
		{
			pwd[i++] = ch;
			printf("*");            // 显示星号代替明文
		}
	}
	printf("\n");
}

int checkgender(char* p) {
	if (strcmp(p, "男") != 0 && (strcmp(p, "女") != 0)) { printf("性别输入非法，请单独重新输入性别即可\n");return -1; }
	return 1;
}

int checkbirth(const char* s) {
	if (strlen(s) != 10) return -1;
	if (s[4] != '/' || s[7] != '/') { printf("日期格式非法，请单独重新输入日期即可\n"); return -1; }
	// 其余位置必须是数字
	for (int i = 0; i < 10; i++) {
		if (i == 4 || i == 7) continue;
		if (s[i] < '0' || s[i] > '9') { printf("日期格式非法，请单独重新输入日期即可\n");return -1; }
	}
	return 1;
}

void menu(int m) {
	
	switch (m) {
	case 0:
		printf("				1.修改自身登录密码\n");
		printf("				2. 添加新教师\n");
		printf("				3. 查看所有教师\n");
		printf("				4. 删除教师\n");
		printf("				5. 修改教师信息\n");
		printf("				6. 退出\n");
		break;
	case 1:
		printf("				1.修改自身登录密码\n");
		printf("				2.查阅自身信息\n");
		printf("				3.添加新学生\n");
		printf("				4.删除学生\n");
		printf("				5.修改学生信息（姓名、性别、出生日期、三门功课成绩）\n");
		printf("				6.查阅指定学生信息\n");
		printf("				7.按学号从低到高查看所有学生信息\n");
		printf("				8.按总分从高到低查看所有学生信息\n");
		printf("				9. 退出\n");
		break;
	case 2:
		printf("				1.修改自身登录密码\n");
		printf("				2. 查阅自身信息\n");
		printf("				3. 退出\n");
		break;
	}
}