﻿#include"project.h"
int main() {
	tea* p = teachercreat();		//教师链表的头节点创建
	stu* pt = studentcreat();		//学生链表的头结点创建
	//启动时从文件读入已有数据（文件不存在则用默认值）
	adminLoad();
	teacherLoad();
	studentLoad();

	system("title 学生信息管理系统");                   //设置窗口标题
	system("mode con cols=120 lines=32");                //设置窗口大小
	system("color F9");		//颜色
	welcome();
	printf("请输入您的身份：（0表示管理员、1表示教师、2表示学生）\n");
	int choice;
	scanf("%d", &choice);

	switch (choice) {

	case 0:
		if (loginadmin() == -1) { return 0; };

		while (1) {
			system("cls");
			menu(choice);
			int r = actionadmin();
			system("pause");
			if (r == -1) { printf("感谢您的使用！\n\n\n");return 0; }
		}

	case 1:
		if (loginteacher() == -1) { return 0; };
		while (1) {
			system("cls");
			menu(choice);
			int r = actionteacher();
			system("pause");
			if (r == -1) { printf("感谢您的使用！\n\n\n");return 0; }
		}
	case 2:
		if (loginstudent() == -1) { return 0; };
		while (1) {
			system("cls");
			menu(choice);
			int r = actionstudent();
			system("pause");
			if (r == -1) { printf("感谢您的使用！\n\n\n");return 0; }
		}
	}
	return 0;
}
