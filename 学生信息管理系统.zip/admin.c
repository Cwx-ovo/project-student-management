﻿#include"project.h"
adm adminer = { "admin","admin123" };
tea* p = NULL;
 tea teacher;//登录实例（定义在 teacher.c），最新添加的教师即它

//========== 文件持久化：管理员 ==========
void adminSave() {//把管理员账号密码写入 admin.txt
	FILE* fp = fopen("admin.txt", "w");
	if (fp == NULL) { printf("admin.txt 打开失败\n"); return; }
	fprintf(fp, "%s %s\n", adminer.account, adminer.password);
	fclose(fp);
}

void adminLoad() {//启动时从 admin.txt 读入，文件不存在则用默认账号
	FILE* fp = fopen("admin.txt", "r");
	if (fp == NULL) {
		strcpy(adminer.account, "admin");
		strcpy(adminer.password, "admin123");
		return;
	}
	fscanf(fp, "%s %s", adminer.account, adminer.password);
	fclose(fp);
}

//========== 文件持久化：教师链表 ==========
void teacherSave() {//把教师链表整体写入 teachers.txt
	FILE* fp = fopen("teachers.txt", "w");
	if (fp == NULL) { printf("teachers.txt 打开失败\n"); return; }
	tea* t = p->next;
	while (t != NULL) {
		fprintf(fp, "%s %s %d %s %s\n",
			t->name, t->psd, t->id, t->gender, t->birth);
		t = t->next;
	}
	fclose(fp);
}

void teacherLoad() {//启动时从 teachers.txt 读入教师链表
	FILE* fp = fopen("teachers.txt", "r");
	if (fp == NULL) return;
	tea* tail = p;
	char name[20], psd[20], gender[20], birth[20];
	int id;
	while (fscanf(fp, "%s %s %d %s %s", name, psd, &id, gender, birth) == 5) {
		tea* q = (tea*)malloc(sizeof(tea));
		if (q == NULL) break;
		strcpy(q->name, name);
		strcpy(q->psd, psd);
		q->id = id;
		strcpy(q->gender, gender);
		strcpy(q->birth, birth);
		q->next = NULL;
		tail->next = q;
		tail = q;
	}
	fclose(fp);
}

tea* teachercreat() {//创建一个教师链表头节点
	p = (tea*)malloc(sizeof(tea));
	if (p == NULL) { printf("p malloc fail\n");return NULL; }
	p->next = NULL;
	return p;
}


int deleteteacher(int id) {//删除指定id的教师
	tea* del = p->next;
	if (del == NULL) { printf("无教师可删除\n"); return 0; }
	tea* h = p;
	while (del != NULL) {
		if (del->id == id) {
			h->next = del->next;
			free(del);
			del = NULL;
			del = h->next;
		}
		else {
			h = h->next;
			del = del->next;
		}
	}
	//删除后重新同步登录实例：链表非空则取头结点（最新教师）
	if (p->next != NULL) {
		strcpy(teacher.name, p->next->name);
		strcpy(teacher.psd, p->next->psd);
		teacher.id = p->next->id;
		strcpy(teacher.gender, p->next->gender);
		strcpy(teacher.birth, p->next->birth);
	}
	return 0;
}

int verifyteaid(int id) {
	tea* temp = p;
	if (p->next == NULL) { return 0; }
	while (temp->next != NULL) {
		temp = temp->next;
		if (temp->id == id) { printf("输入工号与现有工号重复！请单独重新输入工号即可\n");return 1; }
	}
	return 0;
}



tea* addteacher() {//添加一位新教师
	tea* pnew = (tea*)malloc(sizeof(tea));
	if (pnew == NULL) { printf("pnew malloc fail\n");return NULL; }
	printf("请依次输入：姓名、登陆密码、学号、性别、出生年月日、:\n例：xxx xxx123 1001 男 2004/07/22 \n(注意工号不可以重复！！！)\n");
	scanf("%s%s%d%s%s", pnew->name, pnew->psd, &pnew->id, pnew->gender, pnew->birth);
	if (verifyteaid(pnew->id) == 1) {
		while (1) {
			scanf("%d", &pnew->id);
			if (verifyteaid(pnew->id) == 0) { break; }
		}
	}

	if (checkgender(pnew->gender) == -1) {
		while (1) {
			scanf("%s", pnew->gender);
			if (checkgender(pnew->gender) == 1) { break; }
		}
	}

	if (checkbirth(pnew->birth) == -1) {
		printf("日期输入非法，请单独重新输入日期即可\n");
		while (1) {
			scanf("%s", pnew->birth);
			if (checkbirth(pnew->birth) == -1) { printf("日期输入非法，请单独重新输入日期即可\n"); }
			if (checkbirth(pnew->birth) == 1) { break; }
		}
	}
	pnew->next = p->next;
	p->next = pnew;
	//新添加的教师就是当前唯一可登录账号，同步到登录实例 teacher
	strcpy(teacher.name, pnew->name);
	strcpy(teacher.psd, pnew->psd);
	teacher.id = pnew->id;
	strcpy(teacher.gender, pnew->gender);
	strcpy(teacher.birth, pnew->birth);
	return p;
}


int changeteacher() {
	tea* temp = p->next;
	int x;
	if (temp == NULL) { printf("无教师可供修改\n");return -1; }
	printf("请输入您想修改教师的工号：\n");
	scanf("%d", &x);
	while (temp->id != x) {
		temp = temp->next;
	}
	printf("1.name		  2.psd			 3.id		 4.gender		 5.birth\n");
	printf("请输入您想修改的信息：\n");
	int k;
	scanf("%d", &k);
	char name[20]; char psd[20]; int id; char gender[20]; char birth[20];
	switch (k) {

	case 1:
		printf("请输入新的姓名：\n");
		scanf("%s", name);strcpy(temp->name, name);
		printf("修改姓名成功\n");
		break;

	case 2:
		printf("请输入新的密码：\n");
		scanf("%s", psd);strcpy(temp->psd, psd);
		printf("修改密码成功\n");
		break;

	case 3:
		printf("请输入新的工号：\n");
		scanf("%d", &id);temp->id = id;
		printf("修改工号成功\n");
		break;

	case 4:
		printf("请输入性别：\n");
		scanf("%s", gender);strcpy(temp->gender, gender);
		printf("修改性别成功\n");
		break;

	case 5:
		printf("请输入新的出生日期：\n");
		scanf("%s", birth);strcpy(temp->birth, birth);
		printf("修改出生日期成功\n");
		break;
	}
	//修改后重新同步登录实例为头结点（最新教师）
	if (p->next != NULL) {
		strcpy(teacher.name, p->next->name);
		strcpy(teacher.psd, p->next->psd);
		teacher.id = p->next->id;
		strcpy(teacher.gender, p->next->gender);
		strcpy(teacher.birth, p->next->birth);
	}
	return 0;
}

void show() {//显示所有教师信息
	tea* temp = p;
	if (temp->next == NULL) { printf("暂无教师信息\n");return; }
	while (temp->next != NULL) {
		temp = temp->next;
		printf("姓名：%s  密码：%s  工号：%d  性别：%s  出生年月：%s\n\n", temp->name, temp->psd, temp->id, temp->gender, temp->birth);
	}
	return;
}

int loginadmin() {//管理员登录
	char pwd[20];
	char name[20];
	int flag = 0;
	for (int i = 1;i <= 3;i++) {
		printf("请输入管理员账户：\n");
		scanf("%s", name);
		if (strcmp(name, adminer.account) == 0) {
			flag = 1;
			goto end;
		}
		else {
			printf("账户有误，请重试，您还剩%d次机会！\n", 3 - i);
		}
	}
	if (flag == 0) return -1;
end:
	for (int i = 1;i <= 3;i++) {
		printf("请输入密码：\n");
		//scanf("%s", pwd);
		inputPassword(pwd, 20);
		if (strcmp(pwd, adminer.password) == 0) {
			printf("管理员登陆成功！\n");
			return 1;
		}
		else {
			printf("密码错误，请重试，您还剩%d次机会！\n", 3 - i);
		}
	}
	return -1;
}

void changeAdminpwd() {//修改管理员登陆密码
	adm* p = &adminer;
	char newpwd[20];
	printf("请输入新的密码：\n");
	while (1) {
		scanf("%s", newpwd);
		if (strcmp(newpwd, p->password) == 0) { printf("与旧密码重复请重新输入：\n"); }
		else {
			printf("密码修改成功\n");
			strcpy(p->password, newpwd);
			adminSave();//改密成功立刻写回文件
			break;
		}
	}
	return;
}

int actionadmin() {
	int k;
	printf("请输入您想进行的操作：\n");
	scanf("%d", &k);
	switch (k) {
	case 1:
		changeAdminpwd();break;
	case 2:
		addteacher();
		teacherSave();//添加成功立刻写回文件
		printf("添加成功\n");
		break;
	case 3:
		show();break;
	case 4:
		printf("请输入您想删除的教师工号：\n");
		int id;
		scanf("%d", &id);
		deleteteacher(id);
		teacherSave();//删除成功立刻写回文件
		printf("删除成功\n");
		break;
	case 5:
		changeteacher();
		teacherSave();//修改成功立刻写回文件
		break;
	case 6:
		return -1;
	}
	return 0;
}
