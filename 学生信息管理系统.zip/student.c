﻿#include"project.h"
extern stu* pt;

//学生登录，遍历全部学生链表
int loginstudent() {
	char input_name[20];
	char input_pwd[20];
	for (int i = 1;i <= 3;i++)
	{
		printf("请输入学生账户（姓名）：\n");
		scanf("%s", input_name);
		stu* cur = pt->next;
		g_cur_student = NULL;
		while (cur != NULL)
		{
			if (strcmp(cur->name, input_name) == 0)
			{
				for (int j = 1;j <= 3;j++)
				{
					printf("请输入密码：\n");
					inputPassword(input_pwd, 20);
					if (strcmp(cur->psd, input_pwd) == 0)
					{
						g_cur_student = cur;
						printf("学生账户登陆成功！\n");
						return 1;
					}
					else
					{
						printf("密码错误，剩余%d次\n", 3 - j);
					}
				}
				return -1;
			}
			cur = cur->next;
		}
		printf("账户不存在！剩余尝试%d次\n", 3 - i);
	}
	return -1;
}

void changeStudentpwd() {
	if (g_cur_student == NULL) return;
	char newpwd[20];
	printf("请输入新的密码：\n");
	while (1) {
		scanf("%s", newpwd);
		if (strcmp(newpwd, g_cur_student->psd) == 0) {
			printf("与旧密码重复请重新输入：\n");
		}
		else {
			strcpy(g_cur_student->psd, newpwd);
			printf("密码修改成功\n");
			studentSave();
			break;
		}
	}
	return;
}

void showstudentself() {
	if (g_cur_student == NULL) return;
	printf("姓名：%s\n密码：%s\n学号：%d\n性别：%s\n出生年月：%s\n语文：%.2f 数学：%.2f 英语：%.2f\n",
		g_cur_student->name, g_cur_student->psd,
		g_cur_student->id, g_cur_student->gender, g_cur_student->birth,
		g_cur_student->chinese, g_cur_student->math, g_cur_student->english);
	return;
}

int actionstudent() {
	int k;
	printf("请输入您想进行的操作：\n");
	scanf("%d", &k);
	switch (k) {
	case 1:
		changeStudentpwd();
		break;
	case 2:
		showstudentself();
		break;
	case 3:
		return -1;
	}
	return 0;
}